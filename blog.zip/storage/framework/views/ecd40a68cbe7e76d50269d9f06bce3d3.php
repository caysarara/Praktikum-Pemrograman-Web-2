

<?php $__env->startSection('title', 'Tambah Project - Portfolio Caysa'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-header">
        <p class="eyebrow">Portfolio</p>
        <h1>Tambah Project</h1>
        <p class="page-lead">Isi form di bawah untuk menambahkan project baru ke portfolio.</p>
    </section>

    <section class="section">
        <div class="form-card">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert">
                    Data belum bisa disimpan. Periksa kembali isian di bawah.
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('projects.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="nama" class="form-label">Nama Project <span class="req" 
                    aria-hidden="true">*</label>
                    <input type="text" id="nama" name="nama"
                           value="<?php echo e(old('nama')); ?>"
                           class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>"
                           placeholder="Contoh: Dungeon Battle: Rise of Hero">
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="form-error"><?php echo e($message); ?></p>
                    <?php else: ?>
                        <p class="form-hint">Minimal 5 karakter.</p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="deskripsi" class="form-label">Deskripsi <span class="req" 
                    aria-hidden="true">*</span></label>
                    <textarea id="deskripsi" name="deskripsi" rows="5"
                              class="form-control <?php echo e($errors->has('deskripsi') ? 'is-invalid' : ''); ?>"
                              placeholder="Jelaskan project ini secara singkat"><?php echo e(old('deskripsi')); ?>

                            </textarea>
                    <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="form-error" id="deskripsi-error"><?php echo e($message); ?></p>
                    <?php else: ?>
                        <p class="form-hint" id="deskripsi-hint">Minimal 10 karakter.</p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="stack" class="form-label">Stack / Teknologi</label>
                    <input type="text" id="stack" name="stack"
                           value="<?php echo e(old('stack')); ?>"
                           class="form-control <?php echo e($errors->has('stack') ? 'is-invalid' : ''); ?>"
                           placeholder="Java, Java Swing"
                           aria-describedby="stack-hint <?php $__errorArgs = ['stack'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> stack-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           <?php $__errorArgs = ['stack'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-invalid="true" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                    <p class="form-hint">Pisahkan tiap teknologi dengan koma. Boleh dikosongkan.</p>
                    <?php $__errorArgs = ['stack'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="form-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="status" class="form-label">Status <span class="req" aria-hidden="true">*</span></label>
                    <select id="status" name="status"
                            class="form-control <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>">
                        <option value="draft" <?php echo e(old('status', 'published') === 'draft' ? 'selected' : ''); ?>>Draft</option>
                        <option value="published" <?php echo e(old('status', 'published') === 'published' ? 'selected' : ''); ?>>Published</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="form-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Simpan Project</button>
                    <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-outline">Kembali</a>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/projects/create.blade.php ENDPATH**/ ?>