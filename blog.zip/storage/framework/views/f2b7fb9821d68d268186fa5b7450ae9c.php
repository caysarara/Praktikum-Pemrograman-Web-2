<header class="site-header">
    <nav class="navbar">
        <a href="<?php echo e(route('home')); ?>" class="brand">Caysa<span>.</span></a>

        <ul class="nav-links">
            <li>
                <a href="<?php echo e(route('home')); ?>"
                   class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">Home</a>
            </li>
            <li>
                <a href="<?php echo e(route('about')); ?>"
                   class="<?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">About</a>
            </li>
            <li>
                <a href="<?php echo e(route('education')); ?>"
                   class="<?php echo e(request()->routeIs('education') ? 'active' : ''); ?>">Education</a>
            </li>
            <li>
                <a href="<?php echo e(route('projects.index')); ?>"
                   class="<?php echo e(request()->routeIs('projects.*') ? 'active' : ''); ?>">Projects</a>
            </li>
        </ul>
    </nav>
</header>
  <?php /**PATH C:\xampp\htdocs\blog\resources\views/partials/navbar.blade.php ENDPATH**/ ?>