

<?php $__env->startSection('title', 'About - Portfolio Caysa'); ?>

<?php
    $nama = 'Caysa Rara Kirani';
    $deskripsi = 'Mahasiswa Teknologi Rekayasa Perangkat Lunak (TRPL), Sekolah Vokasi, Universitas Gadjah Mada.';
    $skills = [
        'PHP & Laravel',
        'MySQL',
        'Java (OOP, Swing)',
        'HTML, CSS, JavaScript',
        'Python (data processing)',
    ];
?>

<?php $__env->startSection('content'); ?>
    <section class="page-header">
        <p class="eyebrow">Tentang Saya</p>
        <h1><?php echo e($nama); ?></h1>
        <p class="page-lead"><?php echo e($deskripsi); ?></p>
    </section>

    <section class="section">
        <p>
            Sedang menempuh semester 2, aktif mengerjakan mata kuliah Pemrograman
            Berorientasi Objek, Pemrograman Basis Data, Praktikum Pemrograman Web,
            Analisis Algoritma, Statistika, dan Aljabar/Vektor/Matriks.
        </p>
    </section>

    <section class="section">
        <h2>Skill</h2>
        <div class="badge-list">
            <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge"><?php echo e($skill); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/about.blade.php ENDPATH**/ ?>