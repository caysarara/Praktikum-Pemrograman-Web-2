

<?php $__env->startSection('title', 'Education - Portfolio Caysa'); ?>

<?php
    $riwayat = [
        [
            'jenjang' => 'Sarjana Terapan (D4) - Teknologi Rekayasa Perangkat Lunak',
            'institusi' => 'Universitas Gadjah Mada, Sekolah Vokasi',
            'tahun' => 'Sekarang (Semester 2)',
        ],
        // Tambahkan riwayat pendidikan sebelumnya (SMA/SMK, dll) di sini
    ];

    $mataKuliah = [
        'Pemrograman Berorientasi Objek (PPBO)',
        'Pemrograman Basis Data',
        'Praktikum Pemrograman Web',
        'Analisis Algoritma',
        'Statistika',
        'Aljabar, Vektor, dan Matriks',
    ];
?>

<?php $__env->startSection('content'); ?>
    <section class="page-header">
        <p class="eyebrow">Riwayat</p>
        <h1>Education</h1>
    </section>

    <section class="section">
        <div class="timeline">
            <?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="timeline-item">
                    <span class="timeline-year"><?php echo e($item['tahun']); ?></span>
                    <h3><?php echo e($item['jenjang']); ?></h3>
                    <p><?php echo e($item['institusi']); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Belum ada data riwayat pendidikan.</p>
            <?php endif; ?>
        </div>
    </section>

    <section class="section">
        <h2>Mata Kuliah yang Ditempuh</h2>
        <div class="badge-list">
            <?php $__currentLoopData = $mataKuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge"><?php echo e($mk); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/education.blade.php ENDPATH**/ ?>