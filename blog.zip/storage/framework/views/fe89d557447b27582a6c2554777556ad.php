

<?php $__env->startSection('title', $project->nama . ' - Portfolio Caysa'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-header">
        <p class="eyebrow">Detail Project</p>
        <h1><?php echo e($project->nama); ?></h1>
    </section>

    <?php if(session('success')): ?>
        <div class="alert alert-success" role="status"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <section class="section">
        <div class="detail-card">
            <div class="detail-block">
                <h3 class="detail-label">Deskripsi</h3>
                <p class="detail-text"><?php echo e($project->deskripsi); ?></p>
            </div>

            <div class="detail-block">
                <h3 class="detail-label">Status</h3>
                <span class="badge badge-status badge-<?php echo e($project->status); ?>"><?php echo e(ucfirst($project->status)); ?></span>
            </div>

            <div class="detail-block">
                <h3 class="detail-label">Teknologi / Stack</h3>
                <?php if(!empty($project->stack)): ?>
                    <div class="badge-list">
                        <?php $__currentLoopData = $project->stack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge"><?php echo e($tech); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="detail-text detail-empty">Belum ada data teknologi.</p>
                <?php endif; ?>
            </div>
         
            <div class="detail-block">
                <div class="action-group">
                    <a href="<?php echo e(route('projects.edit', $project)); ?>" class="btn btn-primary">Edit</a>

                    <form method="POST"
                          action="<?php echo e(route('projects.destroy', $project)); ?>"
                          class="inline-form"
                          data-confirm="Yakin ingin menghapus project &quot;<?php echo e($project->nama); ?>&quot;?">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/projects/show.blade.php ENDPATH**/ ?>