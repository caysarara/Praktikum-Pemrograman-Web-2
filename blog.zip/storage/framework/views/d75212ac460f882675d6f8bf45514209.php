

<?php $__env->startSection('title', 'Projects - Portfolio Caysa'); ?>

<?php
    $projects = [
        [
            'nama' => 'Dungeon Battle: Rise of Hero',
            'deskripsi' => 'Game RPG berbasis Java Swing, proyek akhir mata kuliah OOP dikerjakan bersama tim (Kelompok 5). Mencakup sistem battle, world map, sprite musuh, dan animasi start screen.',
            'stack' => ['Java', 'Java Swing'],
        ],
        [
            'nama' => 'Bank Sampah Digital',
            'deskripsi' => 'Aplikasi web full-stack untuk praktikum Pemrograman Web, memenuhi kriteria 5 tabel database beserta view, stored procedure, trigger, dan function.',
            'stack' => ['PHP', 'MySQL', 'Bootstrap'],
        ],
        // Tambahkan proyek lain di sini
    ];
?>

<?php $__env->startSection('content'); ?>
    <section class="page-header">
        <p class="eyebrow">Portfolio</p>
        <h1>Projects</h1>
    </section>

    <section class="section">
        <div class="project-grid">
            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="project-card">
                    <h3><?php echo e($project['nama']); ?></h3>
                    <p><?php echo e($project['deskripsi']); ?></p>
                    <div class="badge-list">
                        <?php $__currentLoopData = $project['stack']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge badge-sm"><?php echo e($tech); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Belum ada data proyek.</p>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>console.log('Halaman projects dimuat');</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/projects.blade.php ENDPATH**/ ?>