<?php if($paginator->hasPages()): ?>
    <nav class="pagination" role="navigation" aria-label="Navigasi halaman">
        <ul class="pagination-list">
            
            <?php if($paginator->onFirstPage()): ?>
                <li><span class="page-item disabled" aria-disabled="true">&laquo; Sebelumnya</span></li>
            <?php else: ?>
                <li><a class="page-item" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">&laquo; Sebelumnya</a></li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(is_string($element)): ?>
                    <li><span class="page-item disabled"><?php echo e($element); ?></span></li>
                <?php endif; ?>

                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li><span class="page-item active" aria-current="page"><?php echo e($page); ?></span></li>
                        <?php else: ?>
                            <li><a class="page-item" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li><a class="page-item" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">Berikutnya &raquo;</a></li>
            <?php else: ?>
                <li><span class="page-item disabled" aria-disabled="true">Berikutnya &raquo;</span></li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/vendor/pagination/portofolio.blade.php ENDPATH**/ ?>