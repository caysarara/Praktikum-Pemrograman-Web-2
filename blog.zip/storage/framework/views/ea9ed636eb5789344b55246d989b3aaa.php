

<?php $__env->startSection('title', 'Trash Projects - Portfolio Caysa'); ?>

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('projects.index')); ?>" class="back-link"><span aria-hidden="true">&larr;</span> Kembali ke daftar project</a>

    <section class="page-header">
        <p class="eyebrow">Portfolio</p>
        <h1>Trash</h1>
        <p class="page-lead">Project yang sudah dihapus. Pulihkan atau hapus permanen.</p>
    </section>

    <?php if(session('success')): ?>
        <div class="alert alert-success" role="status"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <section class="section">
        <div class="project-grid">
            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="project-card">
                    <span class="badge badge-sm badge-status badge-<?php echo e($project->status); ?>"><?php echo e(ucfirst($project->status)); ?></span>
                    <h3><?php echo e($project->nama); ?></h3>
                    <p><?php echo e($project->deskripsi); ?></p>

                    <div class="card-footer">
                        <p class="trash-meta">Dihapus: <?php echo e($project->deleted_at->format('d M Y, H:i')); ?></p>

                        <div class="action-group">
                            <form method="POST" action="<?php echo e(route('projects.restore', $project->id)); ?>" class="inline-form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <button type="submit" class="btn btn-outline btn-sm">Restore</button>
                            </form>

                            <form method="POST" action="<?php echo e(route('projects.force-delete', $project->id)); ?>" class="inline-form"
                                  data-confirm="Hapus permanen project &quot;<?php echo e($project->nama); ?>&quot;? Data tidak bisa dikembalikan.">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Hapus Permanen</button>
                            </form>
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state">
                    <p>Trash kosong.</p>
                    <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-outline">Kembali</a>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/projects/trash.blade.php ENDPATH**/ ?>