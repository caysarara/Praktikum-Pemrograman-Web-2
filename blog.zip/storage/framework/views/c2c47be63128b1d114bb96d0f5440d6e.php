

<?php $__env->startSection('title', 'Projects - Portfolio Caysa'); ?>

<?php $__env->startSection('content'); ?>
    <section class="page-header page-header-row">
        <div>
            <p class="eyebrow">Portofolio</p>
            <h1>Projects</h1>
            <p class="page-lead">Kumpulan proyek yang pernah saya kerjakan.</p>
        </div>
         <div class="action-group">
            <a href="<?php echo e(route('projects.trash')); ?>" class="btn btn-outline">Trash (<?php echo e($trashedCount); ?>)</a>
            <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-primary">Tambah Project</a>
        </div>
    </section>

    <?php if(session('success')): ?>
        <div class="alert alert-success" role="status"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="filter-tabs">
        <a href="<?php echo e(route('projects.index', request()->only(['search', 'per_page']))); ?>"
           class="<?php echo e(request('status') !== 'published' ? 'active' : ''); ?>">Semua</a>
        <a href="<?php echo e(route('projects.index', array_merge(request()->only(['search', 'per_page']), ['status' => 'published']))); ?>"
           class="<?php echo e(request('status') === 'published' ? 'active' : ''); ?>">Published</a>
    </div>

    <form method="GET" action="<?php echo e(route('projects.index')); ?>" class="toolbar">
        <?php if(request('status') === 'published'): ?>
            <input type="hidden" name="status" value="published">
        <?php endif; ?>

        <input type="search" name="search" value="<?php echo e($search); ?>"
               class="form-control toolbar-search" placeholder="Cari judul project..."
               aria-label="Cari judul project">

        <select name="per_page" class="form-control toolbar-select"
                aria-label="Jumlah data per halaman" onchange="this.form.submit()">
            <?php $__currentLoopData = [5, 10, 25]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($size); ?>" <?php if($perPage === $size): echo 'selected'; endif; ?>><?php echo e($size); ?> per halaman</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <button type="submit" class="btn btn-primary btn-sm">Cari</button>

        <?php if($search !== ''): ?>
            <a href="<?php echo e(route('projects.index', array_filter(['status' => request('status'), 'per_page' => $perPage]))); ?>"
               class="btn btn-outline btn-sm">Reset</a>
        <?php endif; ?>
    </form>

    <section class="section">
        <div class="project-grid">
            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="project-card">
                    <span class="badge badge-sm badge-status badge-<?php echo e($project->status); ?>"><?php echo e(ucfirst($project->status)); ?></span>
                    <h3><?php echo e($project->nama); ?></h3>
                    <p><?php echo e($project->deskripsi); ?></p>

                    <?php if(!empty($project->stack)): ?>
                        <div class="badge-list">
                            <?php $__currentLoopData = $project->stack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge badge-sm"><?php echo e($tech); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <div class="card-footer">
                        <div class="card-actions">
                            <a href="<?php echo e(route('projects.show', $project)); ?>" class="card-link">
                                Lihat Detail<span aria-hidden="true">&rarr;</span>
                            </a>
                           
                            <div class="action-group">
                                <a href="<?php echo e(route('projects.edit', $project)); ?>" class="btn btn-outline btn-sm">Edit</a>
                                <form method="POST" action="<?php echo e(route('projects.destroy', $project)); ?>" class="inline-form" data-confirm="Apakah Anda yakin ingin menghapus proyek ini?">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state">
                    <p>Belum ada data proyek.</p>
                    <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-outline">Tambah Project</a>
                </div>
            <?php endif; ?>
        </div>
        <div class="pagination-bar">
            <div class="pagination-info">
                Halaman : <?php echo e($projects->currentPage()); ?> dari <?php echo e($projects->lastPage()); ?> <br>
                Jumlah Data : <?php echo e($projects->total()); ?> <br>
                Data Per Halaman : <?php echo e($projects->perPage()); ?>

            </div>

            <?php echo e($projects->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>
    <script>console.log('Halaman projects dimuat');</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/projects/index.blade.php ENDPATH**/ ?>