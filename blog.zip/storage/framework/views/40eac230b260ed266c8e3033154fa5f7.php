<footer class="site-footer">
    <p>&copy; <?php echo e(date('Y')); ?> Portofolio Caysa</p>
</footer>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/partials/footer.blade.php ENDPATH**/ ?>